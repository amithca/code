import pandas as pd
casts=pd.read_csv('cast.csv',index_col=None)
print(casts.head())