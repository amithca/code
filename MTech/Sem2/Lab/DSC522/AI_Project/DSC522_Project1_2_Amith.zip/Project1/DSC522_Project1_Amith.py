'''
Amith C A
2020MCS120003
DSC522 Lab Assignment 1
'''
import networkx as nx
import matplotlib.pyplot as plt
import time
import random
from statistics import mean
from fpdf import FPDF

pwd = 'C:/Users/amith/OneDrive/MTech/Sem2/Lab/DSC522/'
start_node = 0
goal_node = 380
output_file_name = 'DSC522_Project1_BFS_DFS_Analysis'
dfs = []
bfs=''
def dfs_paths(g, start, goal, path=None):
    time.sleep(0.001)
    if path is None:
        path = [start]
    if start == goal:
        yield path
    for next in set(g[start]) - set(path):
        yield from dfs_paths(g, next, goal, path + [next])


def BFS_SP(g, start, goal):
    explored = []
    path = []
    queue = [[start]]
    if start == goal:
        print("Same Node")
        return
    while queue:
        time.sleep(0.001)
        path = queue.pop(0)
        node = path[-1]
        if node not in explored:
            neighbours = g[node]
            for neighbour in neighbours:
                new_path = list(path)
                new_path.append(neighbour)
                queue.append(new_path)
                if neighbour == goal:
                    # print("Shortest path = ", *new_path)
                    return new_path
            explored.append(node)
    print("Connecting" \
          "path doesn't exist :(")
    return


def get_dfs_time_complexity(graph, start_node, sample_nodes):
    elapsed_times = []
    for node in sample_nodes:
        if node != start_node:
            dfs_time = get_dfs_time(graph, start_node, node)
            elapsed_times.append(dfs_time)
    return elapsed_times


def get_bfs_time_complexity(graph, start_node, sample_nodes):
    elapsed_times = []
    for node in sample_nodes:
        if node != start_node:
            bfs_time = get_bfs_time(graph, start_node, node)
            elapsed_times.append(bfs_time)
    return elapsed_times


def get_dfs_time(T, start, goal):
    dfs = []
    start_time = time.time()
    dfs = list(dfs_paths(T, start, goal))
    end_time = time.time()
    print(f'Start={start}, Goal={goal}, DFS Shortest path = {dfs[0]}')
    elapsed_time = end_time - start_time
    return elapsed_time


def get_bfs_time(T, start, goal):
    start_time = time.time()
    bfs = BFS_SP(T, start, goal)
    end_time = time.time()
    print(f'Start={start}, Goal={goal}, BFS Shortest path = {bfs}')
    elapsed_time = end_time - start_time
    return elapsed_time


def set_colour(graph, shortest_path):
    node_colors = []
    for n in graph.nodes():
        if n == start_node:
            node_colors.append("yellow")
        elif n == goal_node:
            node_colors.append("green")
        elif n in shortest_path:
            node_colors.append("blue")
        else:
            node_colors.append("red")
    return node_colors


def create_graph_img(g, g_colors, file_name):
    nx.draw(g, with_labels=True, font_weight='bold', node_color=g_colors)
    plt.savefig(f'{pwd}/tmp/{file_name}.png')
    plt.clf()


def create_graph(graph, file):
    for line in file:
        if not line.startswith("#"):
            (vertex1, sep, vertex2) = line.partition("\t")
            vertex1 = vertex1.strip()
            vertex2 = vertex2.strip()
            graph.add_edge(int(vertex1), int(vertex2))
    return graph


def plot_time_complexity(x_coordinates, y1_coordinates, y2_coordinates, file_name):
    plt.xlabel("Node")
    plt.ylabel("Time Complexity")
    plt.xticks(rotation=45)
    plt.plot(x_coordinates, y1_coordinates, '-rD', label='DFS')
    plt.plot(x_coordinates, y2_coordinates, '-bD', label='BFS')
    plt.legend()
    plt.savefig(f'{pwd}/tmp/{file_name}.png')
    plt.clf()


def plot_time_complexity_with_average(x_coordinates, y1_coordinates, y2_coordinates, file_name):
    plt.xlabel("Node")
    plt.ylabel("Time Complexity")
    plt.xticks(rotation=45)
    y1_mean = [mean(y1_coordinates)] * len(x_coordinates)
    y2_mean = [mean(y2_coordinates)] * len(x_coordinates)
    plt.plot(x_coordinates, y1_coordinates, '-rD', label='DFS')
    plt.plot(x_coordinates, y2_coordinates, '-bD', label='BFS')
    plt.plot(x_coordinates, y1_mean, '-r', label='Mean', linestyle='--')
    plt.plot(x_coordinates, y2_mean, '-b', label='Mean', linestyle='--')
    plt.legend()
    # plt.show()
    plt.savefig(f'{pwd}/tmp/{file_name}.png')
    plt.clf()

def generate_report(pwd, output_file_name):
    PAGE_WIDTH = 210
    PAGE_HEIGHT = 297
    pdf = FPDF('P', 'mm', 'A4')  # Page format

    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    '''Page : 1'''
    page_title = 'Bfs Dfs ComplexityAnalysis'
    pdf.ln(PAGE_HEIGHT * .4)
    pdf.write(10, f"{page_title}")
    pdf.ln(PAGE_HEIGHT * .4)
    pdf.set_font('Arial', '', 10)
    pdf.write(5, "Amith C A\n2020MCS120003\nDSC523 Project 1")
    pdf.ln(10)
    '''Page : 2'''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "Computational Complexity")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    with open(f'{pwd}content/txt/Computational_complexity_intro.txt', 'r') as f:
        tmp_content = f.read()
    pdf.write(10, tmp_content)
    pdf.ln(20)
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "Time Complexity")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    with open(f'{pwd}content/txt/Time_complexity_into.txt', 'r') as f:
        tmp_content = f.read()
    pdf.write(10, tmp_content)
    pdf.ln(20)
    '''Page : 3'''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "Big-O Notation")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    with open(f'{pwd}content/txt/Big_O_intro.txt', 'r') as f:
        tmp_content = f.read()
    pdf.write(10, tmp_content)
    pdf.ln(20)

    node_list = []
    '''Page : 2''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    complexity_analysis = BfsDfsComplexityAnalysis(
        file=f"{pwd}Dataset/Cit-HepTh/Cit-HepTh.txt", test_node_count=25)
    complexity_analysis.analyse()

    '''
    pdf.set_font('Arial', 'BU', 10)
    pdf.write(10, "Table of common time complexities")
    pdf.ln(15)
    pdf.set_font('Arial', '', 10)
    big_o_table = {
        "Constant Time": "O(1)",
        "Logarithmic Time": "O(log n)",
        "Linear Time": "O(n)",
        "Quasilinear Time": "O(n log n)",
        "Quadratic Time": "O(n^2)",
        "Exponential Time": "O(2^n)",
        "Factorial Time": "O(n!)"
    }
    pdf.cell(40, 7, 'Name', 1)
    pdf.cell(40, 7, 'Time Complexity', 1)
    pdf.ln()
    for key, value in big_o_table.items():
        pdf.cell(40, 6, key, 1)
        pdf.cell(40, 6, value, 1)
        pdf.ln()
    '''Page : 4'''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "Depth First Search")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    with open(f'{pwd}content/txt/DFS.txt', 'r') as f:
        tmp_content = f.read()
    pdf.write(10, tmp_content)
    pdf.ln(20)
    '''Page : 5'''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "DFS Tree")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    pdf.write(10, f'The Shortest path from start node {start_node} to goal node {goal_node} is : {dfs[0]}')
    pdf.write(10, "DFS Tree plot: ")
    pdf.image(f'{pwd}tmp/dfs_tree_shortest_path.png', 5, 30, PAGE_WIDTH - 5)
    '''Page : 6'''
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.write(10, "BFS Tree")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    pdf.write(10, f'The Shortest path from start node {start_node} to goal node {goal_node} is : {bfs}')
    pdf.write(10, "BFS Tree plot: ")
    pdf.image(f'{pwd}tmp/bfs_tree_shortest_path.png', 5, 30, PAGE_WIDTH - 5)
    '''Page : 7'''
    pdf.add_page()
    pdf.set_font('Arial', 'BU', 16)
    pdf.write(10, "Time complexity analysis of BFS vs DFS")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    pdf.write(10, f'The time complexity plot of BFS vs DFS is as below:')
    pdf.image(f'{pwd}tmp/time_complexity.png', 5, 30, PAGE_WIDTH - 5)
    '''Page : 8'''
    pdf.add_page()
    pdf.set_font('Arial', 'BU', 16)
    pdf.write(10, "Time complexity analysis of BFS vs DFS (Average)")
    pdf.ln(20)
    pdf.set_font('Arial', '', 10)
    pdf.write(10, f'The time complexity plot of BFS vs DFS is as below:')
    pdf.image(f'{pwd}tmp/time_complexity_avg.png', 5, 30, PAGE_WIDTH - 5)
    pdf.output(f'{pwd}/{output_file_name}.pdf', 'F')

if __name__ == '__main__':
    graph = nx.Graph()

    with open(f'{pwd}/Dataset/roadNet-CA.txt', 'r') as f:
        graph = create_graph(graph, f)
    dfs_tree = nx.dfs_tree(graph, source=start_node, depth_limit=None)
    bfs_tree = nx.bfs_tree(graph, source=start_node, depth_limit=None)


    dfs = list(dfs_paths(dfs_tree, start_node, goal_node))
    print('DFS Shortest path = ', dfs[0])
    bfs = BFS_SP(bfs_tree, start_node, goal_node)
    print('BFS Shortest path = ', bfs)
    '''Create Shortest path image'''
    dfs_node_colors = set_colour(dfs_tree, dfs[0])
    create_graph_img(dfs_tree, dfs_node_colors, 'dfs_tree_shortest_path')
    bfs_node_colors = set_colour(bfs_tree, bfs)
    create_graph_img(bfs_tree, bfs_node_colors, 'bfs_tree_shortest_path')
    '''Calculate time complexities'''
    no_of_nodes = 25
    nodes = graph.nodes()
    print('nodes=', set(nodes))
    sample_nodes = random.sample(set(nodes) - set([start_node]), no_of_nodes)

    print('sample_nodes=', sample_nodes)
    dfs_elapsed_times = get_dfs_time_complexity(dfs_tree, start_node, sample_nodes)
    bfs_elapsed_times = get_bfs_time_complexity(bfs_tree, start_node, sample_nodes)
    # print(dfs_elapsed_times)
    plot_time_complexity(x_coordinates=sample_nodes, y1_coordinates=dfs_elapsed_times,
                         y2_coordinates=bfs_elapsed_times, file_name='time_complexity')
    plot_time_complexity_with_average(x_coordinates=sample_nodes, y1_coordinates=dfs_elapsed_times,
                                      y2_coordinates=bfs_elapsed_times, file_name='time_complexity_avg')
    generate_report(pwd, output_file_name)
